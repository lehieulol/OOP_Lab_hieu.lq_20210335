package hust.soict.dsai.test;

import java.util.ArrayList;

import hust.soict.dsai.aims.media.Book;

public class TestMediaBuilder {

	public static void main(String[] args) {
		ArrayList<String> au = new ArrayList<String>();
		au.add("Au");
		au.add("Ag");
		Book a = (Book) new Book.Builder().author(au).category("Category").cost(10).title("Title").build();
		System.out.print(a.toString());
	}

}
