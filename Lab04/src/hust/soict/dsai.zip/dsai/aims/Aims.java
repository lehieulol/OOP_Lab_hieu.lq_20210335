package hust.soict.dsai.aims;

import hust.soict.dsai.aims.cart.Cart;
import hust.soict.dsai.aims.media.Disc;

//Revamp with new Builder Path

public class Aims {

	public static void main(String[] args) {
		Cart anOrder = new Cart();
		
		Disc dvd1 = new Disc("The Lion King", "Animation", "Roger Aller", 87, 19.95f);
		Disc dvd2 = new Disc("Star Was", "Science Fiction", "George Lucas", 87, 24.95f);
		Disc dvd3 = new Disc("Aladin", "Animation", 18.99f);
		
		anOrder.addDigitalVideoDisc(dvd1,dvd2);
		anOrder.addDigitalVideoDisc(dvd2);
		anOrder.addDigitalVideoDisc(dvd3);

		anOrder.removeDigitalVideoDisc(dvd3);
		
		System.out.println("Total cost is: ");
		System.out.println(anOrder.totalCost());
	}

}
