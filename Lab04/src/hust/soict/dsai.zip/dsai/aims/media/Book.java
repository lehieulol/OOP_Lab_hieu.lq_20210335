package hust.soict.dsai.aims.media;

import java.util.ArrayList;

public class Book extends Media{
	private ArrayList<String> author;
	
	// Builder	
	public static class Builder<SELF extends Builder, TARGET extends Book> extends Media.Builder<SELF, TARGET>{
		ArrayList<String> author = new ArrayList<String>();
		public Builder() {};
		
		public SELF author(ArrayList<String> author) {
			this.author = author;
			return self();
		}
		@Override
		protected TARGET internalBuild() {
			return (TARGET) new Book(this);
		}
	}
	public static Builder builder() {
		return new Builder<Builder, Book>();
	}
	// Builder Constructor
	public Book(Builder builder) {
		super(builder);
		this.author = builder.author;
	}
	public ArrayList<String> getAuthor() {
		return author;
	}
	@Override
	public String toString() {
		return String.format("Book - %s\t- %s\t", this.author.toString(), super.toString());
	}
}
