package hust.soict.dsai.aims.media;

import java.lang.reflect.Type;

public abstract class Media {
	int id;
	String title, category;
	float cost;

	static private int idNext = 0;
	
	public abstract static class Builder<SELF extends Builder, TARGET extends Media>{
		int id;
		String title = "", category = "";
		float cost = 0;
		public Builder() {};
		
		public SELF title(String title) {
			this.title = title;
			return self();
		}
		public SELF category(String category) {
			this.category = category;
			return self();
		}
		public SELF cost(float cost) {
			this.cost = cost;
			return self();
		}
		protected SELF self() {
			System.out.println(((SELF) this).getClass());
			return (SELF) this;
		}
		protected abstract TARGET internalBuild();
		public TARGET build() {
			return internalBuild();
		}
	}
	
	public Media(Builder builder){
		this.id = Media.idNext++;
		this.title = builder.title;
		this.category = builder.category;
		this.cost = builder.cost;
	}
	
	public int getId() {
		return id;
	}
	public String getTitle() {
		return title;
	}
	public String getCategory() {
		return category;
	}
	public float getCost() {
		return cost;
	}
	public String toString() {
		return String.format("%s\t- %s\t - %.2f$", this.title, this.category, this.cost);
	}
	public boolean isMatch(int id) {
		if (this.id == id) {
			return true;
		}
		return false;
	}
}
