package hust.soict.dsai.aims.media;

import java.util.ArrayList;

public class CompactDisc extends Disc implements Playable{
	
	String artist;
	ArrayList<Track> tracks;
	//Builder
	public static class Builder<SELF extends Builder, TARGET extends CompactDisc> extends Disc.Builder<SELF, TARGET>{
		String artist;
		ArrayList<Track> tracks = new ArrayList<Track>();
		public Builder() {};
		public SELF artist(String artist) {
			this.artist = artist;
			return self();
		}
		public SELF tracks(ArrayList<Track> tracks) {
			this.tracks = tracks;
			return self();
		}
		protected TARGET internalBuild() {
			return (TARGET) new CompactDisc(this);
		}
	}
	public static Builder builder() {
		return new Builder<Builder, CompactDisc>();
	}
	//Constructor
	public CompactDisc(Builder builder) {
		super(builder);
		this.artist = builder.artist;
		this.tracks = builder.tracks;
	}
	
	public boolean addTrack(Track track) {
		if(tracks.contains(track)) {
			System.out.println("Track already existed");
			return false;
		}
		this.tracks.add(track);
		System.out.println("Track added successfully");
		return true;
	}
	
	public boolean removeTrack(Track track) {
		if(!tracks.remove(track)) {
			System.out.println("Track not existed");
			return false;
		}
		return true;
	}
	
	public String getArtist() {
		return artist;
	}

	public int getLength() {
		int sum = 0;
		for(Track track : tracks) {
			sum += track.getLength();
		}
		return sum;
	}

	@Override
	public void play() {
		System.out.println("Playing compact disc: " + this.getTitle() + " by " + this.getArtist()); 
		System.out.println("Compact disc length: " + this.getLength());
		for(Track track : tracks) {
			track.play();
		}
	}
}
