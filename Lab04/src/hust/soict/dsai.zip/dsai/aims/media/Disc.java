package hust.soict.dsai.aims.media;

public class Disc extends Media{
	private String directory;
	private int length;
	
	public static class Builder<SELF extends Builder, TARGET extends Disc> extends Media.Builder<SELF, TARGET>{
		private String directory = "";
		private int length = 0;
		public Builder() {};
		
		public SELF directory(String directory) {
			this.directory = directory;
			return self();
		}
		
		public SELF length(int length) {
			this.length = length;
			return self();
		}

		@Override
		protected TARGET internalBuild() {
			return (TARGET) new Disc(this);
		}
	}
	public static Builder builder() {
		return new Builder<Disc.Builder, Disc>();
	}
	public Disc(Builder builder) {
		super(builder);
		this.directory = builder.directory;
		this.length = builder.length;
		
	}

	public String getDirectory() {
		return directory;
	}
	public int getLength() {
		return length;
	}
	public String toString() {
		return String.format("Disc - %d\t- %s\t- %s", this.length, this.directory, super.toString());
	}
}
