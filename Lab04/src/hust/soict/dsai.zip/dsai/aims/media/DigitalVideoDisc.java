package hust.soict.dsai.aims.media;

public class DigitalVideoDisc extends Disc implements Playable{
	
	public static class Builder<SELF extends Builder, TARGET extends DigitalVideoDisc> extends Disc.Builder<SELF, TARGET>{
		public Builder() {};

		@Override
		public TARGET internalBuild() {
			return (TARGET) new DigitalVideoDisc(this);
		}
	}
	public static Builder builder() {
		return new Builder<Builder, DigitalVideoDisc>();
	}
	public DigitalVideoDisc(Builder builder) {
		super(builder);
	}
	
	@Override
	public void play() {
		System.out.println("Playing DVD: " + this.getTitle()); 
		System.out.println("DVD length: " + this.getLength());
	}

	

}
