package hust.soict.dsai.aims;

public class ObjectWrapper {
	Object obj;
}
