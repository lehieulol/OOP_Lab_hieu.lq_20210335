package hust.soict.dsai.aims.store;

import java.util.Arrays;

import hust.soict.dsai.aims.media.Disc;

public class Store {
	private static final int MAX_VOLUMN = 500;
	Disc itemInStore[] = new Disc[Store.MAX_VOLUMN];
	int qtyItem = 0;
	
	public boolean addDVD (Disc disc) {
		if (this.qtyItem == Store.MAX_VOLUMN) {
			System.out.println("Store full, cannot order more!");
			return false;
		}
		if (Arrays.asList(this.itemInStore).contains(disc)) {
			System.out.println("Item is already in the store");
			return false;
		}
		this.itemInStore[this.qtyItem] = disc;
		this.qtyItem += 1;
		System.out.println("Item is added successfully");
		return true;
	}
	
	public boolean removeDVD (Disc disc) {
		if (! Arrays.asList(this.itemInStore).contains(disc)) {
			System.out.println("Item is unavailable");
			return false;
		}
		int index = Arrays.asList(this.itemInStore).indexOf(disc);
		for (int i = index; i < this.qtyItem - 1; i++) {
			this.itemInStore[i] = this.itemInStore[i+1];
		}
		this.itemInStore[this.qtyItem - 1] = new Disc("<Deleted Token>");
		this.qtyItem -= 1;
		System.out.println("Item is removed successfully");
		return true;
	}
}
