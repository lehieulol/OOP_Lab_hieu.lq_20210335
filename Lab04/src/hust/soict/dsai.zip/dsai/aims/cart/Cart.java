package hust.soict.dsai.aims.cart;
import java.util.ArrayList;

import hust.soict.dsai.aims.media.Media;

// Need to revamp

public class Cart {
	private ArrayList<Media> itemOrdered = new ArrayList<Media>();
	
	public boolean add(Media media) {
		if (this.itemOrdered.contains(media)) {
			System.out.println("Item is already in the cart");
			return false;
		}
		this.itemOrdered.add(media);
		System.out.println("Item is added successfully");
		return true;
	}
	
	public int add(ArrayList<Media> medias) {
		int count = 0;
		for(Media media: medias) {
			boolean a = this.add(media);
			if (a) {
				count++;
			}
		}
		return count;
	}
	
	public boolean remove(Media media) {
		if (! this.itemOrdered.remove(media)) {
			System.out.println("Item is unavailable");
			return false;
		}
		System.out.println("Item is removed successfully");
		return true;		
	}
	
	public float totalCost() {
		float sum = 0;
		for (Media media : this.itemOrdered) {
			sum += media.getCost();
		}
		return sum;
	}
	
	public void print() {
		System.out.println("***********************CART***********************");
		System.out.println("Ordered Items:");
		int i = 0;
		for (Media media : this.itemOrdered) {
			System.out.println(String.format("%d. %s", ++i, media.toString()));
		}
		System.out.println(String.format("Total cost: %.2f $", this.totalCost()));
	}
	
	public boolean search(int id) {
		for (Media media : this.itemOrdered) {
			if (media.isMatch(id)) {
				System.out.println("Item found: " + media.toString());
				return true;
			}
		}
		System.out.println("Item not found.");
		return false;
	}
}
